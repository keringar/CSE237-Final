extern "C" {
void gen_metrics_k7_n3(const char* seq,
		   	   	   	   const short* out,
					   short* sums,
					   short* paths,
					   int norm) {
	// gen_metrics_k7_n3
	short metrics[32] = {0};

	// _gen_branch_metrics_n3(64, seq, out, metrics);
	for (int k = 0; k < 32; k++) {
		metrics[k] = seq[0] * out[4 * k + 0] +
					 seq[1] * out[4 * k + 1] +
					 seq[2] * out[4 * k + 2];
	}

	// _gen_path_metrics(64, sums, metrics, paths, norm);
	short new_sums[64];
	for (int k = 0; k < 32; k++) {
		short metric = metrics[k];

		int state0 = sums[2 * k + 0];
		int state1 = sums[2 * k + 1];

		if (sum0 > sum1) {
			new_sums[k] = state0 + metric;
			paths[k] = -1;
		} else {
			new_sums[k] = state1 - metric;
			paths[k] = 0;
		}

		if (sum2 > sum3) {
			new_sums[k + 32] = state0 - metric;
			paths[k + 32] = -1;
		} else {
			new_sums[k + 32] = state1 + metric;
			paths[k + 32] = 0;
		}
	}

	if (norm) {
		short min = new_sums[0];
		for (int k = 0; k < 64; k++) {
			if (new_sums[k] < min) {
				min = new_sums[k];
			}
		}

		for (int k = 0; k < 64; k++) {
			new_sums[k] -= min;
		}
	}

	for (int k = 0; k < 64; k++) {
		sums[k] = new_sums[k];
	}
}
}

extern "C" {
void gen_metrics_k9_n3(const char* seq,
					   const short* out,
					   short* sums,
					   short* paths,
					   int norm) {
	// gen_metrics_k7_n3
	short metrics[128] = {0};

	// _gen_branch_metrics_n3(256, seq, out, metrics);
	for (int k = 0; k < 128; k++) {
		metrics[k] = seq[0] * out[4 * k + 0] +
					 seq[1] * out[4 * k + 1] +
					 seq[2] * out[4 * k + 2];
	}

	// _gen_path_metrics(256, sums, metrics, paths, norm);
	short new_sums[256];
	for (int k = 0; k < 128; k++) {
		short metric = metrics[k];

		int state0 = sums[2 * k + 0];
		int state1 = sums[2 * k + 1];

		if (sum0 > sum1) {
			new_sums[k] = state0 + metric;
			paths[k] = -1;
		} else {
			new_sums[k] = state1 - metric;
			paths[k] = 0;
		}

		if (sum2 > sum3) {
			new_sums[k + 128] = state0 - metric;
			paths[k + 128] = -1;
		} else {
			new_sums[k + 128] = state1 + metric;
			paths[k + 128] = 0;
		}
	}

	if (norm) {
		short min = new_sums[0];
		for (int k = 0; k < 256; k++) {
			if (new_sums[k] < min) {
				min = new_sums[k];
			}
		}

		for (int k = 0; k < 256; k++) {
			new_sums[k] -= min;
		}
	}

	for (int k = 0; k < 256; k++) {
		sums[k] = new_sums[k];
	}
}
}
