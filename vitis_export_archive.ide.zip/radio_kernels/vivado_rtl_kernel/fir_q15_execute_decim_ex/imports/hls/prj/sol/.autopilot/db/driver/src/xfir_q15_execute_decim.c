// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xfir_q15_execute_decim.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XFir_q15_execute_decim_CfgInitialize(XFir_q15_execute_decim *InstancePtr, XFir_q15_execute_decim_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XFir_q15_execute_decim_Start(XFir_q15_execute_decim *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFir_q15_execute_decim_ReadReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_AP_CTRL) & 0x80;
    XFir_q15_execute_decim_WriteReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XFir_q15_execute_decim_IsDone(XFir_q15_execute_decim *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFir_q15_execute_decim_ReadReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XFir_q15_execute_decim_IsIdle(XFir_q15_execute_decim *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFir_q15_execute_decim_ReadReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XFir_q15_execute_decim_IsReady(XFir_q15_execute_decim *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFir_q15_execute_decim_ReadReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XFir_q15_execute_decim_EnableAutoRestart(XFir_q15_execute_decim *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFir_q15_execute_decim_WriteReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XFir_q15_execute_decim_DisableAutoRestart(XFir_q15_execute_decim *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFir_q15_execute_decim_WriteReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_AP_CTRL, 0);
}

void XFir_q15_execute_decim_Set_x0r(XFir_q15_execute_decim *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFir_q15_execute_decim_WriteReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_X0R_DATA, Data);
}

u32 XFir_q15_execute_decim_Get_x0r(XFir_q15_execute_decim *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFir_q15_execute_decim_ReadReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_X0R_DATA);
    return Data;
}

void XFir_q15_execute_decim_Set_x0i(XFir_q15_execute_decim *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFir_q15_execute_decim_WriteReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_X0I_DATA, Data);
}

u32 XFir_q15_execute_decim_Get_x0i(XFir_q15_execute_decim *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFir_q15_execute_decim_ReadReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_X0I_DATA);
    return Data;
}

void XFir_q15_execute_decim_Set_x1r(XFir_q15_execute_decim *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFir_q15_execute_decim_WriteReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_X1R_DATA, Data);
}

u32 XFir_q15_execute_decim_Get_x1r(XFir_q15_execute_decim *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFir_q15_execute_decim_ReadReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_X1R_DATA);
    return Data;
}

void XFir_q15_execute_decim_Set_x1i(XFir_q15_execute_decim *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFir_q15_execute_decim_WriteReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_X1I_DATA, Data);
}

u32 XFir_q15_execute_decim_Get_x1i(XFir_q15_execute_decim *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFir_q15_execute_decim_ReadReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_X1I_DATA);
    return Data;
}

void XFir_q15_execute_decim_Set_y(XFir_q15_execute_decim *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFir_q15_execute_decim_WriteReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_Y_DATA, (u32)(Data));
    XFir_q15_execute_decim_WriteReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_Y_DATA + 4, (u32)(Data >> 32));
}

u64 XFir_q15_execute_decim_Get_y(XFir_q15_execute_decim *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFir_q15_execute_decim_ReadReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_Y_DATA);
    Data += (u64)XFir_q15_execute_decim_ReadReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_Y_DATA + 4) << 32;
    return Data;
}

void XFir_q15_execute_decim_InterruptGlobalEnable(XFir_q15_execute_decim *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFir_q15_execute_decim_WriteReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_GIE, 1);
}

void XFir_q15_execute_decim_InterruptGlobalDisable(XFir_q15_execute_decim *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFir_q15_execute_decim_WriteReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_GIE, 0);
}

void XFir_q15_execute_decim_InterruptEnable(XFir_q15_execute_decim *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFir_q15_execute_decim_ReadReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_IER);
    XFir_q15_execute_decim_WriteReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_IER, Register | Mask);
}

void XFir_q15_execute_decim_InterruptDisable(XFir_q15_execute_decim *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFir_q15_execute_decim_ReadReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_IER);
    XFir_q15_execute_decim_WriteReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_IER, Register & (~Mask));
}

void XFir_q15_execute_decim_InterruptClear(XFir_q15_execute_decim *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFir_q15_execute_decim_WriteReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_ISR, Mask);
}

u32 XFir_q15_execute_decim_InterruptGetEnabled(XFir_q15_execute_decim *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFir_q15_execute_decim_ReadReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_IER);
}

u32 XFir_q15_execute_decim_InterruptGetStatus(XFir_q15_execute_decim *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFir_q15_execute_decim_ReadReg(InstancePtr->Control_BaseAddress, XFIR_Q15_EXECUTE_DECIM_CONTROL_ADDR_ISR);
}

